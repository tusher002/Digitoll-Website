<?php
//database.php
$connection = mysqli_connect("digitollbd.com","pranto","Cpanel@login07","digitoll","3306");
?>